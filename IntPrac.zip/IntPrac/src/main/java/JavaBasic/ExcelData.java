package JavaBasic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelData {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file =    new File("C:\\New folder\\data.xlsx");
		FileInputStream is = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(is);
		
		XSSFSheet sheet=wb.getSheet("Personal_Data");
		//XSSFSheet sheet1=wb.getSheetAt(0);
		XSSFRow row1=sheet.getRow(2);
		
		XSSFCell cell=row1.getCell(5);
		
		String address= cell.getStringCellValue();
		System.out.println("Address is : "+ address);

	}

}
