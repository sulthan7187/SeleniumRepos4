package JavaBasic;

public class AddofDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 10329, rem = 0;
		while(a>0) {
			rem += a%10;
			a = a/10;
		}
		System.out.println(rem);

	}

}
