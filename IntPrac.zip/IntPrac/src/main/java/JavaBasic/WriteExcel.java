package JavaBasic;

import java.io.File;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class WriteExcel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		// Create a workbook of .xlsx format
					Workbook workbook = WorkbookFactory.create(true);

					// Add a new sheet as Sheet 1
					Sheet sheet = workbook.createSheet("Sheet 1");

					// Create a new Row in Excel Sheet and add data
					Row row = sheet.createRow(0);
					row.createCell(0).setCellValue("TestScript");
					row.createCell(1).setCellValue("UserName");
					row.createCell(2).setCellValue("Password");

					// Create another Row and add data
					Row row1 = sheet.createRow(1);
					row1.createCell(0).setCellValue("TC_002");
					row1.createCell(1).setCellValue("Admin");
					row1.createCell(2).setCellValue("Admin@123");

					// Write data to TestData1.xlsx file
					workbook.write(new FileOutputStream(new File("C:\\New folder\\empty.xlsx")));
					System.out.println("Success");
				} 
	catch (Exception e) {
					e.printStackTrace();
				}

	}

}
