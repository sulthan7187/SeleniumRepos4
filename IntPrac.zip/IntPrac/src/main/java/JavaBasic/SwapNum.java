package JavaBasic;

public class SwapNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int[] a = {12,23,34,45,56,67};
		int b = a.length;
		int c= 0, d=0, e;
		
		for(int i=0;i<b;i++) {
			if(a[i]==23) {
				c =i;
			}
			if(a[i]==56) {
				d=i;
			}
		}
		e = a[c];
		a[c]=a[d];
		a[d]=e;
		
		for(int f : a) {
			System.out.print(f + " ");
		}
		

	}

}
