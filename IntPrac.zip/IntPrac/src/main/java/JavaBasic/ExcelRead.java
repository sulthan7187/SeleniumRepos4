package JavaBasic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelRead {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		File fl = new File("C:\\New folder\\newfile.xlsx");
		FileInputStream is = new FileInputStream(fl);
		XSSFWorkbook wb = new XSSFWorkbook(is);
		
		XSSFSheet st = wb.getSheetAt(0);
		XSSFRow rw = st.getRow(1);
		XSSFCell cl = rw.getCell(4);
		
	     long numericCellValue = (long) cl.getNumericCellValue();
		
		System.out.println(numericCellValue);

	}

}
