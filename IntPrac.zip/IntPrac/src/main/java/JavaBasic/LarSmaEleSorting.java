package JavaBasic;

import java.util.Arrays;

public class LarSmaEleSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {12,43,45,64,23,49,65,87};
		int b = a.length;
		for(int i = 0; i<b; i++) {
			for(int j = i+1; j<b; j++) {
				if(a[i]<a[j]) {
					int c = a[i];
					a[i] = a[j];
					a[j] = c;
				}		
			}
			System.out.print(a[i]+" ");
		}
		System.out.print("\n" + a[b-7]);

	}

}
