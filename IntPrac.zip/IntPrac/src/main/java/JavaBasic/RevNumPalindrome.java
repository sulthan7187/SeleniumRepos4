package JavaBasic;

public class RevNumPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 123323, sum = 0, temp,rem;
		temp =a;
		while(a>0) {
			rem = a%10;
			sum = sum*10 + rem;
			a = a/10;
		}
		System.out.println(sum);
		if(temp==sum) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
		

	}

}
