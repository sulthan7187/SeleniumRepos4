package JavaBasic;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class DupSent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "I Work Work in Capgemini";
		String[] s1 = s.split(" ");
		int a = s1.length;
		
		Set<String> uniq = new LinkedHashSet<String>();
		Set<String> dup = new LinkedHashSet<String>();
		
		for(int i = 0; i<a; i++) {
			String c = s1[i];
			if(!uniq.add(c)) {
				dup.add(c);
				uniq.remove(c);
				}
			}
		for(String u : uniq) {
			System.out.print(u + " ");
		}
		for(String v : dup) {
			System.out.println("\n" + v);
		}

	}

}
