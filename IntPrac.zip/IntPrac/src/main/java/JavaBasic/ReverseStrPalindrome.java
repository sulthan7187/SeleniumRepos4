package JavaBasic;

public class ReverseStrPalindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Autootua";
		String s2 = "";
		int a = s.length();
		for(int i = (a-1); i>=0; i--) {
		  s2 = s2 + s.charAt(i);
		}
		System.out.println(s2);
		if(s.toLowerCase().equals(s2.toLowerCase())) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}

	}

}
