package JavaBasic;

public class Primewithmultiple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 2; i<=120; i++) {
			int count = 0;
			for(int n = 1; n<=i; n++) {
				if(i%n==0) {
					count ++;
				}
			}
			if(count==2) {
				System.out.print(" " + i);
			}
		}

	}

}
