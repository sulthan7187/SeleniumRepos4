package JavaBasic;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class DupEleNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {12,23,34,56,34,23,48};
		int b = a.length;
		
		Set<Integer> uniq = new LinkedHashSet<Integer>();
		Set<Integer> dup = new LinkedHashSet<Integer>();
		
		for(int i =0; i<b; i++) {
			int c = a[i];
			if(!dup.contains(c)) {
				if(!uniq.add(c)) {
					dup.add(c);
					//uniq.remove(c);
				}
			}
		}
		for(int d : uniq) {
			System.out.print(d+ " ");
		}
		System.out.println("\n" +uniq);
		System.out.println(dup);
	}

}
