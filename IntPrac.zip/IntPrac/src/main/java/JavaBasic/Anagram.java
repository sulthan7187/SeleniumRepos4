package JavaBasic;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Act";
		String b = "Cat";
		
		a = a.toLowerCase();
		b = b.toLowerCase();
		
		int c = a.length();
		int d = b.length();
		
		if(c!= d) {
			System.out.println("It is not an Anagram");
			return;
		}
		
		char[] chrA = a.toCharArray();
		char[] chrB = b.toCharArray();
		
		Arrays.sort(chrA);
		Arrays.sort(chrB);
		
		for(int i = 0; i<c; i++) {
			if(chrA[i]!=chrB[i]) {
				System.out.println("Not an Anagram");
				return;
			}	
		}
        System.out.println("It is an Anagram");
	}

}
