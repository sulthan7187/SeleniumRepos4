package JavaBasic;

public class StarProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int n = 3; // Number of rows
	        for (int i = 1; i <= n; i++) {
	            // Print spaces before stars
	          for (int j = 1; j <= n - i; j++) {
	                System.out.print(" ");
	            }
	            // Print stars
	            for (int k = 1; k <= i; k++) {
	                System.out.print("*"+ " ");
	            }
	            // Move to the next line after printing each row
	            System.out.println();
	        }

	}

}
