package JavaBasic;

public class SwappingStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] s = {"Java", "C++", "C", "Python", "Ruby"};
		String e = "";
		int a = s.length;
		int b =0, c=0;
		
		for(int i =0;i<a;i++) {
			if(s[i].equals("C++")) {
				b = i;
			}
			if(s[i].equals("C")) {
				c = i;
			}
		}
		e = s[b];
		s[b] = s[c];
		s[c] = e;
		
		for(String v : s) {
			System.out.print(v + " ");
		}

	}

}
