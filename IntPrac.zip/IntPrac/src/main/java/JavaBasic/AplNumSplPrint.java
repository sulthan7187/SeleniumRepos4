package JavaBasic;

public class AplNumSplPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s = "DEEPA erwerwerw 22565 *(&@&$";
		//String r = s.replaceAll(" ", "");
		//System.out.println(r);
		//String repAll = s.replaceAll("[0-9]","");
		//System.out.println(repAll);
		int b = s.length();
		for(int i = 0; i<b;i++) {
			char c = s.charAt(i);
			if( c>= '0' && c<='9') {
				if(c>='A' && c<='z') {
				System.out.print(c);
			}
			}
		}
		

	}

}
