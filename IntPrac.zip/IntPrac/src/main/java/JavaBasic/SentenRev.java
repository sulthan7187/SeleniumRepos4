package JavaBasic;

public class SentenRev {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Apple is sweet";
		String[] sp = a.split(" ");
		
		String rev ="";
		for(String g : sp) {
			String str ="";
			int v = g.length();
		for(int i = v-1; i>=0; i--) {
			str = str + g.charAt(i);
		}
		rev = rev + str + " ";
		}
		System.out.println(rev);

	}

}
