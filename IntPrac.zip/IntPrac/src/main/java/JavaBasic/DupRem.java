package JavaBasic;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class DupRem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Automation";
		int b = s.length();
		String d = s.toLowerCase();
		Set<Character> uniq = new HashSet<Character>();
		Set<Character> dup = new HashSet<Character>();
		for(int i = 0; i<b;i++) {
			char c = d.charAt(i);
			if(!dup.contains(c)) {
				if(!uniq.add(c)) {
					dup.add(c);
					uniq.remove(c);
				}
			}
		}
		System.out.println(uniq);
		System.out.println(dup);

	}

}
