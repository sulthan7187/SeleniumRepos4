package PracJava;

public class PrimeNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i = 2; i<=100; i++) {
			int c=0;
			for(int n = 1; n<=i;n++) {
				if(i%n==0) {
					c++;
				}
			}
			if(c==2) {
				System.out.print(" "+i);
			}
		}
	

	}

}
