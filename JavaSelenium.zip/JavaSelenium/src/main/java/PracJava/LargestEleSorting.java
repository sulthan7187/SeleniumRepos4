package PracJava;

import java.util.Arrays;

public class LargestEleSorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[] = {12,24,24322,1345,124325,1223};
		int b = a.length;
		Arrays.sort(a);
		System.out.println("\n"+a[b-3]);
		
		for(int i = 0; i<b;i++) {
			for(int j = i+1; j<b; j++) {
				if(a[i]<a[j]) {
					int c = a[i];
					a[i]=a[j];
					a[j]=c;
				}
			}
			System.out.print(a[i]+ " ");
		}
		System.out.println("\n"+a[b-3]);

	}

}
