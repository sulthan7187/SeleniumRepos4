package PracJava;

public class BNYMJava {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
