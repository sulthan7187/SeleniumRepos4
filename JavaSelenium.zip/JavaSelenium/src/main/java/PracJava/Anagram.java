package PracJava;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Acts";
		String g = "Cats";
		
		String rep = s.replaceAll("//s", "").toLowerCase();
		String rell = g.replaceAll("//s", "").toLowerCase();
		
		int a = rep.length();
		int b = rell.length();
		
		if(a!=b) {
			System.out.println("It is not an Anagram");
			return;
		}
		
		char[] ch1 = rep.toCharArray();
		char[] ch2 = rell.toCharArray();
		
		Arrays.sort(ch2);
		Arrays.sort(ch1);
		
		for(int i = 0; i<a;i++) {
			if(ch1[i]!=ch2[i]) {
				System.out.println("It is not an Anagram");
				return;
			}
		}
		System.out.println("It is an Anagram");
		
		

	}

}
