package PracJava;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 0,count = 0;
		if(n>1&&n==0) {
		for(int i =1; i<=100; i++) {
			if(n%i==0) {
				count++;
			}
		}
		}
		if(n==1) {
			System.out.println("1 is neither prime nor composite");
			}
		
		if(n>1) {
		if(count==2) {
			System.out.println("Prime");
		}
		else {
			System.out.println("Not Prime");
		}
		}

	}

}
