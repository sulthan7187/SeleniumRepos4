package PracJava;

import java.util.Arrays;

public class BNYM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {3,4,1,5,2};
		Arrays.sort(a);
		int b = a.length;
		//System.out.println(a);
		for(int c:a) {
			System.out.print("\n"+c+" ");
		}
		for(int i = 0; i<b;i++) {
			String d = "A"+ a[i];
			if(i>=1) {
			d = "_"+d;
			}
			System.out.print(d);
		}
		

	}

}
