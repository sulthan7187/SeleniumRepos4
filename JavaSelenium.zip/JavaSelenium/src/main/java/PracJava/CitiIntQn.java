package PracJava;

public class CitiIntQn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 5, b = 10;
		b=  b-a; // 10-5 = 5
		a = a+b; // 5+5= 10;
		
		System.out.println("a = "+ a);
		System.out.println("b = "+ b);

	}

}
