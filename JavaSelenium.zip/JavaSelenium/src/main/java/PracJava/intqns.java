package PracJava;

import java.util.Arrays;
import java.util.HashMap;

public class intqns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str = "Automation";
		String upr = str.toUpperCase();
        HashMap<Character, Integer> charCountMap = new HashMap<>();

        // Counting characters
        for (char c : upr.toCharArray()) {
        	
            // Incrementing the count if the character is already present in the map
            // Otherwise, adding the character with count as 1
            Integer put = charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
        }
        

        // Printing the character counts
        System.out.println("Character counts:");
        for (char c : charCountMap.keySet()) {
            System.out.println("'" + c + "' : " + charCountMap.get(c));
        }
		

	}

}
