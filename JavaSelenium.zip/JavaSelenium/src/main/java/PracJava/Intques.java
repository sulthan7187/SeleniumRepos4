package PracJava;

public class Intques {
	public static void main(String[] args) {
		String a = "2";
		String b = "3";
	  
		double d = Double.parseDouble(a);
		double e = Double.parseDouble(b);
		
		double c = d/e;
		System.out.println(c);
	}

}
