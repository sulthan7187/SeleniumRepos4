package PracJava;

public class PalindromeRevStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String fer = "Automotu";
		String rev = "";
		int a = fer.length();
		
		for(int i = a-1; i>=0;i--) {
			rev = rev + fer.charAt(i);
		}
		System.out.println(rev);
		if(rev.toLowerCase().equals(fer.toLowerCase())) {
			System.out.println("It is Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}

	}

}
