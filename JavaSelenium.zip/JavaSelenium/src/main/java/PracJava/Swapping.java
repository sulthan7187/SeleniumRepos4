package PracJava;

public class Swapping {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] a = {"C++","Java","Python","Php"};
		String rev = "";
	    int b = a.length;
	    int temp1 = 0, temp2 = 0;
		for(int i = 0; i<b;i++) {
			if(a[i].equals("C++")) {
				temp1 = i;
			}
			if(a[i].equals("Java")) {
				temp2 = i;
			}
		}
		rev = a[temp1];
		a[temp1]=a[temp2];
		a[temp2]=rev;
		
		for(String c : a) {
			System.out.print(c + " ");
		}
		
		System.out.println("\n" + rev);

	}

}
