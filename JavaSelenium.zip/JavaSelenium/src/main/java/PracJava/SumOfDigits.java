package PracJava;

public class SumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 193847;
		int rem, sum = 0;
		while(a>0) {
			rem = a%10;
			sum+=rem;
			a =a/10;
		}
		System.out.println(sum);

	}

}
