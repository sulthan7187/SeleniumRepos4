package IntPractise;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BMShow {
	public static void main(String[] args) {
		
		String s = "AuttuA";
		String rev = "";
		int a = s.length();
		for(int i = (a-1);i>=0;i--) {
			rev = rev + s.charAt(i);
		}
		System.out.println(rev);
		if(rev.toLowerCase().equals(s.toLowerCase())) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
	}

}
