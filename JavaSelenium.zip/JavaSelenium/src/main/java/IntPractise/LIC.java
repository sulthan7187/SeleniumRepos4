package IntPractise;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class LIC {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		driver.get("https://licindia.in/hi/web/guest/careers?p_p_id=com_lic_career_web_CareerWebPortlet_INSTANCE_zyoz&amp;p_p_lifecycle=0&amp;p_p_state=normal&amp;p_p_mode=view&amp;_com_lic_career_web_CareerWebPortlet_INSTANCE_zyoz_javax.portlet.action=getCareerDetails%22);");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		Select ss = new Select(driver.findElement(By.xpath("//label[contains(text(), 'Select Region')]//following-sibling::select")));
		ss.selectByVisibleText("All");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		Select as = new Select(driver.findElement(By.xpath("//label[contains(text(), 'Select Department')]//following::select")));
		as.selectByVisibleText("All");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		driver.findElement(By.xpath("//span[contains(text(), 'Search')]")).click();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(8));
		WebElement f2 = driver.findElement(By.xpath("//select[contains(@name, 'tableID_length')]"));
		String text = f2.getText();
		System.out.println(f2);
		Select bs = new Select(f2);
		bs.selectByVisibleText("100");
		
		System.out.println(f2.getText());
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,450)", "");
		
		WebElement findElement = driver.findElement(By.xpath("//div[contains(text(), 'Showing 1 to 6 of 6 entries')]"));
		System.out.println(findElement.getText());
		
	}

}
