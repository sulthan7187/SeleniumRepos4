package IntPractise;

import java.util.Arrays;
import java.util.List;

public class JavaProg {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 0, b=0;
	    for(int i = 1; i<=101; i++) {
	    	if(i%2==0) {
	    		a += i;
	    	}
	    	else {
	    		b +=i;
	    }
	    }
	    System.out.println("\n" + a);
       System.out.println("\n" + b);
        a = b-a;
       System.out.println(a);
	}
}



