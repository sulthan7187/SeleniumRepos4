package JavaCodes;

public class StrNumORAlp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Aeirndi379283*@*&&*@873";
		String b = a.replaceAll("[A-Za-z0-9]", "");
		System.out.println(b);
		String c = "Capgemini";
		String d = c.replaceAll("Capge", "minis");
		//System.out.println(d);
		String e = d.replaceAll("smini", "Capge");
		//System.out.println(e);

	}

}
