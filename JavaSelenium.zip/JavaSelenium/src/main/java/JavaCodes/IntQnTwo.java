package JavaCodes;

public class IntQnTwo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String value = "100A 100B 100C";

        // 1st way
       // value = value.replaceAll("[^0-9 ]", "");
        String s2 = value.replaceAll("[!0-9]", "");
        //System.out.println(value);
        System.out.println(s2);

	}

}
