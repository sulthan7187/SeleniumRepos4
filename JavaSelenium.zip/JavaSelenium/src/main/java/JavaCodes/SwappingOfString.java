package JavaCodes;

public class SwappingOfString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		String strValues[] = {"Python", "C", "C++", ".Net", "Java"};
		String tempValue = "";
		int temp1 = 0, temp2 = 0;
		int d = strValues.length;
		for(int i=0; i<d; i++)
		{
			if(strValues[i].equals("Java"))
			{
				temp1 = i;
			}
			if(strValues[i].equals("Pyhton"))
			{
				temp2 = i;
			}
		}

		tempValue = strValues[temp1];
		strValues[temp1] = strValues[temp2];
		strValues[temp2] = tempValue;
		System.out.println(tempValue);
		for(String c : strValues) {
			System.out.print(" "+c);
		}
		

	}

}
