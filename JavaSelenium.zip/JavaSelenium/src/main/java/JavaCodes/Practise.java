package JavaCodes;

public class Practise {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "Apple";
		String revstr = "";
		int a = str.length();
		for(int i = a-1; i>=0; i--) {
			revstr = revstr + str.charAt(i);
		}
		System.out.println(revstr);
	}

}
