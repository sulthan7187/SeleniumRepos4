package JavaCodes;

public class PrimeNumSingle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 113, count = 0, range = 1000;
		if(n>0) {
			for(int i =1; i<range; i++) {
				if(n%i==0) {
					count++;
				}
			}
			if(count==2) {
				System.out.println("Prime");
			}
			else {
				System.out.println("Not Prime");
			}
		}

	}

}
