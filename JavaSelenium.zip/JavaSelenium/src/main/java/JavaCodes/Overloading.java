package JavaCodes;

public class Overloading {

	public int add(int a, int b) {
         int c = a + b;
		return c;
    }

    // Method to add three integers (overloaded version)
    public int add(int a, int b, int c) {
         int d =  a + b + c;
         return d;
    }

}
