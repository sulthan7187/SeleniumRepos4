package JavaCodes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DupUniqSingleNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {1,2,3,4,5,3,2};
		int b = a.length;
		
		Set<Integer> uniq = new HashSet<Integer>();
		Set<Integer> dup = new HashSet<Integer>();
		
		for(int i =0; i<b; i++) {
			int c = a[i];
			if(!dup.contains(c)) {
				if(!uniq.add(c)){
					dup.add(c);
				    uniq.remove(c);
					
				}
			}
		}
		System.out.println(uniq);
		System.out.println(dup);
		Object[] string = uniq.toArray();
		Arrays.sort(string);
		for(Object f : string) {
		System.out.print(" "+ f);
		}

	}

}
