package JavaCodes;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.time.LocalTime;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DynamicSelectnScreenShot {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		
//		Thread.sleep(5000);
		try {
			LocalTime startTime = LocalTime.now();
			
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			LocalTime endTime = LocalTime.now();
			
			System.out.println("Imp - Start Time: " + startTime);
			System.out.println("Imp - End Time: " + endTime);
			
			LocalTime startTimeExp = LocalTime.now();
			LocalTime endTimeExp = null;
			try {
				driver.findElement(By.xpath("//input[contains(@id, 'fromCity')]")).click();
			WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(15));
		    wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@id, 'fromCity')]")))
					.click();
			endTimeExp = LocalTime.now();
			}catch(Exception e) {
				endTimeExp = LocalTime.now();
			}finally {
				System.out.println("Exp - Start Time: " + startTimeExp);
				System.out.println("Exp - End Time: " + endTimeExp);
			}

			
			driver.findElement(By.xpath("//input[contains(@placeholder, 'From')]")).sendKeys("Mum");
			List<WebElement> list = driver.findElements(By.xpath("//li[contains(@role, 'option')]"));
			String a = "Mumbai";
			/*
			 * System.out.println(list.size()); list.get(3).click();
			 */
			for (WebElement b : list) {
				String d = b.getText();
				if (d.contains(a)) {
					b.click();
				}

			}
		} catch (Exception e) {
			File f = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			// Files.(f, new
			// File("C:\\TestLeaf\\SeleniumCucumber\\test-output\\Screenshots"));
			FileUtils.copyFile(f, new File(".//ScreenShotSul/Sucfai.png"));
			System.out.println("this " + e.getMessage());

		}

	}
}
