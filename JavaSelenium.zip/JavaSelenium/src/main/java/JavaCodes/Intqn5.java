package JavaCodes;

import java.util.LinkedHashMap;
import java.util.Map;

public class Intqn5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        // Create a LinkedHashMap with String keys and Integer arrays as values
	        LinkedHashMap<String, Integer[]> map = new LinkedHashMap<>();
	 
	        // Add entries to the map
	        map.put("India", new Integer[]{1, 2});
	        map.put("Australia", new Integer[]{3, 4});
	        map.put("England", new Integer[]{5, 6});
	 
	        // Iterate through the map and print the entries in the required format
	        for (Map.Entry<String, Integer[]> entry : map.entrySet()) {
	            String country = entry.getKey();
	            Integer[] values = entry.getValue();
	            System.out.print(country + " - ");
	            for (int i = 0; i < values.length; i++) {
	                System.out.print(values[i]);
	                if (i < values.length - 1) {
	                    System.out.print(", ");
	                }
	            }
	            System.out.println();
	        }
	    }


	}


