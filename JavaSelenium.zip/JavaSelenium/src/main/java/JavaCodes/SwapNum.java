package JavaCodes;

public class SwapNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {10,20,30,40,50};
		int b = a.length;
		int c = 0;
		int d = 0;
		for(int i = 0; i<b; i++) {
			if(a[i] == 10) {
				c=i;
			}
			if(a[i]==30) {
				d=i;
			}
		}
		int e = a[c];
		a[c]=a[d];
		a[d]=e;
		for(int f : a) {
		System.out.print(" "+f);
		}

	}

}
