package JavaCodes;

import java.time.Duration;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CitiIntques {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/search?q=calculator&sca_esv=a2d6f7b350eb119b&sca_upv=1&sxsrf=ADLYWIKWhsfGV9V96ANeduR5-MPlcqSbTg%3A1720069762390&source=hp&ei=gi6GZvykFfPg2roP9MypyAo&iflsig=AL9hbdgAAAAAZoY8kvRqyfQfxKBxSzH3HBF_gchkUx42&oq=calculator&gs_lp=Egdnd3Mtd2l6IgpjYWxjdWxhdG9yKgIIADILEAAYgAQYsQMYgwEyCBAAGIAEGLEDMggQABiABBixAzILEAAYgAQYsQMYgwEyCBAAGIAEGLEDMggQABiABBixAzILEAAYgAQYsQMYgwEyCBAAGIAEGLEDMggQABiABBixAzIIEAAYgAQYsQNIrxlQAFjYDnAAeACQAQCYAdwBoAHeDqoBBTAuNy4zuAEByAEA-AEBmAIKoAKRD8ICChAjGIAEGCcYigXCAgQQIxgnwgIREC4YgAQYsQMY0QMYgwEYxwHCAg4QABiABBixAxiDARiKBcICDhAuGIAEGLEDGNEDGMcBwgILEC4YgAQYsQMYgwHCAgUQABiABMICCBAuGIAEGLEDmAMAkgcFMC42LjSgB-JG&sclient=gws-wiz");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		String atext = Integer.toString(a);
		WebDriverWait ws = new WebDriverWait(driver, Duration.ofSeconds(10));
		WebElement until = ws.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[contains(@class,'PaQdxb A2W7l')]//div[contains(text(),'" +atext+ "')]")));
		until.sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//div[contains(text(),'�')]")).click();
		Thread.sleep(5000);
		
		Scanner nc = new Scanner(System.in);
		int b = nc.nextInt();
		String btext = Integer.toString(b);
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(10));
		wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[contains(@class,'PaQdxb A2W7l')]//div[contains(text(),'"+btext+"')]"))).click();
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//div[contains(text(),'=')]")).click();
		Thread.sleep(5000);
		
		WebElement n = driver.findElement(By.xpath("//span[contains(@id, 'cwos')]"));
		System.out.println(n.getText());

	}

}
