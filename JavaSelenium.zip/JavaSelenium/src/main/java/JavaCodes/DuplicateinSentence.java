package JavaCodes;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class DuplicateinSentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="I work work in Capgemini";
		String s2[] = s.split(" ");
		
		Map<String, Integer> s3 = new LinkedHashMap<String, Integer>();
		
		for(String c : s2) {
			if(s3.containsKey(c)) {
				int b = s3.get(c);
				Integer put = s3.put(c, b + 1);
				//System.out.println(put);
			}
			else {
				s3.put(c, 1);
			}
		}
		System.out.println(s3);

	}

}
