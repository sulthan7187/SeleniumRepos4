package JavaCodes;

public class LarSmaEleSortAscDesc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {12,32,42,65,76,45,54,86,34};
		int b = a.length;
		for(int i =0; i<b; i++) {
			for(int j = i+1; j<b; j++) {
				if(a[i]>a[j]) {
					int c=a[i];
					a[i]=a[j];
					a[j]=c;
				}
			}
			System.out.print(a[i]+" ");
		}
		System.out.println('\n'+"Second Largest Element " + a[b-1]);

	}

}
