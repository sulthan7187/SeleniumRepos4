package JavaCodes;

public class Construct {
    String name;
    public Construct(String name) {
          this.name = name;
          System.out.println(name);
    }
    public static void main(String[] args) {
    	Construct d = new Construct("Simba");
    }

}
