package JavaCodes;

public class ScbIntques {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       /* String s = "deeepaa erwerwerw 22565";
        
        // Iterate through each character in the string
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            
            // Check if the character is a digit
            if (Character.isAlphabetic(c)) {
                System.out.print(c);
            }
        }
        System.out.println();*/
        
           String s = "deeepaa erwerwerw 22565";
        
        // Iterate through each character in the string
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            
            // Check if the character is a digit (ASCII range for digits: '0' to '9')
            if (c >= '0' && c <= '9') {
                System.out.print(c);
            }
        }
        //System.out.println();
	}

}
