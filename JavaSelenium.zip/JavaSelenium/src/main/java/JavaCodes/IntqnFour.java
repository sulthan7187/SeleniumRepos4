package JavaCodes;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class IntqnFour {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        List<String[]> countries = new ArrayList<>();
        
        // Add countries along with their numbers
        countries.add(new String[]{"India", "1", "2"});
        countries.add(new String[]{"Australia", "3", "4"});
        countries.add(new String[]{"England", "5", "6"});
        
        // Print the output in the specified format
        for (String[] country : countries) {
            System.out.println(country[0] + " - " + country[1] + " ," + country[2]);
        }

	}

}
