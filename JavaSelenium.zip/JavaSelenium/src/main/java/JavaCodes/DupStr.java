package JavaCodes;

import java.util.LinkedHashSet;
import java.util.Set;

public class DupStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Automation";
		String s1 = s.toLowerCase();
		
		char[] ch = s1.toCharArray();
		Set<Character> uniq = new LinkedHashSet<Character>();
		Set<Character> dup = new LinkedHashSet<Character>();
		int b = ch.length;
		
		for(int i = 0; i<b; i++) {
			if(!uniq.add(ch[i])) {
			dup.add(ch[i]);
			uniq.remove(ch[i]);
			
		}
		}
		System.out.println(uniq);
		System.out.println(dup);
		
	}

}
