package JavaCodes;

public class OddEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 13;
		 if(a%2==0) {
			 System.out.println("Even");
		 }
		 else {
			 System.out.println("Odd");
		 }

	}

}
