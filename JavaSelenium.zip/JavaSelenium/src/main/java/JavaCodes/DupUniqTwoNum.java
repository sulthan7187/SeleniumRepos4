package JavaCodes;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DupUniqTwoNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> list1 = Arrays.asList(1,2,3,4,5);
		List<Integer> list2 = Arrays.asList(4,5,1,7,9);
		
		Set<Integer> uniq = new HashSet<Integer>(list1);
		uniq.addAll(list2);
		System.out.println(uniq);
		
		Set<Integer> dup = new HashSet<Integer>(list1);
		dup.retainAll(list2);
		System.out.println(dup);
		uniq.removeAll(dup);
		System.out.println(uniq);
		

	}

}
