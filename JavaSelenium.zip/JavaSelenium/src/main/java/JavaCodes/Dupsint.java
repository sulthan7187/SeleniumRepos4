package JavaCodes;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Dupsint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {5,3,2,4,1,3,2};
		int b = a.length;
		
		Set<Integer> inte = new TreeSet<Integer>();
		Set<Integer> dup = new TreeSet<Integer>();
		
		for(int i = 0; i<b; i++) {
			int c = a[i];
			if(!inte.add(a[i])) {
				dup.add(a[i]);
			}
		}
		System.out.println(inte);
		System.out.println(dup);
		

	}

}
