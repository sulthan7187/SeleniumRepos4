package JavaCodes;

public class PlaindromeRevString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "PloyyolP is good";
		String rev = "";
		int a = s.length();
		for(int i=a-1;i>=0;i--) {
			rev = rev+s.charAt(i);
		}
		if(s.toLowerCase().equals(rev.toLowerCase())) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}
        System.out.println("Reverse " + rev);
	}

}
