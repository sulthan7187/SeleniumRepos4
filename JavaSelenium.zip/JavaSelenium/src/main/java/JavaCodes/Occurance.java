package JavaCodes;

public class Occurance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Automationt";
		String b = s.toLowerCase();
		int c = b.length();
		String s2 = b.replaceAll("t", "");
		System.out.println(s2);
		int d = s2.length();
		int a = c-d;
		System.out.println("Occurance of t is " + a);

	}

}
