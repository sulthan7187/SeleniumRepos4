package JavaCodes;

import java.util.LinkedHashSet;
import java.util.Set;

public class Dups {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s ="I work work in Capgemini";
		String s2[] = s.split(" ");
		int count = 0;
		
		Set<String> str = new LinkedHashSet<String>();
		Set<String> dup = new LinkedHashSet<String>();
	
		for(int i = 0; i<s2.length;i++) {
			String b = s2[i];
			if(!str.add(b)){
				dup.add(b);
				str.remove(b);
			}
			
		}
		System.out.println(str);
		System.out.println(dup);
		

	}

}
