package JavaCodes;

public class Interqns {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "20241212";
		String s1 = s.substring(0, 4);
		String s2 = s.substring(4, 6);
		String s3 = s.substring(6, 8);
		System.out.println(s1 + "-" + s2 + "-" + s3);
		int b = s.length();
		String v = "";
		for(int i = 0; i<b;i++) {
			char c = s.charAt(i);
			if(i == 4 || i == 6) {
			 v += "-";
			}
			v += c;
		}
      System.out.println(v);
	}

}
