package JavaCodes;

import java.util.HashSet;
import java.util.Set;

public class DupUniqSingStr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Automation";
		int a = s.length();
		String s1 = s.toLowerCase();
		
		Set<Character> uniq = new HashSet<Character>();
		Set<Character> dup = new HashSet<Character>();
		for(int i=0; i<a; i++) {
			char c = s1.charAt(i);
			if(!dup.contains(c)) {
				if(!uniq.add(c)) {
					dup.add(c);
					uniq.remove(c);
					
				}
			}
		}
		System.out.println(uniq);
		System.out.println(dup);

	}
}
