package JavaCodes;

import java.util.Arrays;

public class Sorting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] a = {12,32,42,65,76,45,54,86,34};
		Arrays.sort(a);
        for(int num :a) {
        	System.out.print(" "+ num);
        }
	}

}
