package JavaCodes;

import java.util.Arrays;

public class IntQn {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a [] = {3,4,1,5,2,6};
	    Arrays.sort(a);
	    int c = a.length;
	    for(int i=0; i<c; i++){
	        String b = "A"+a[i];
	        if(i!=c-1){
	            b=b+"_";
	            }
	        System.out.print(b);
	    }

	}

}
