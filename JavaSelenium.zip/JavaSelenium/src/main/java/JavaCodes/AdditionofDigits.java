package JavaCodes;

public class AdditionofDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 103253, sum=0;
		while(a>0) {
			sum+= a%10;
			a=a/10;
		}
		System.out.println("The Sum of 103253 is : " + sum);

	}
}

