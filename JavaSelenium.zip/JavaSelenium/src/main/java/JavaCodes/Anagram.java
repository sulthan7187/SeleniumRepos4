package JavaCodes;

import java.util.Arrays;

public class Anagram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Pants";
		String b = "Napstq";

		// Remove all white spaces and convert strings to lowercase
		a = a.replaceAll("\\s", "").toLowerCase();
		b = b.replaceAll("\\s", "").toLowerCase();
		System.out.println(a);
		System.out.println(b);

		int c = a.length();
		int d = b.length();

		if (c != d) {  
		    System.out.println("Not an anagram");
		    return;
		}

		// Convert strings to char arrays
		char[] charArrayA = a.toCharArray();
		char[] charArrayB = b.toCharArray();

		// Sort the char arrays
		Arrays.sort(charArrayA);
		Arrays.sort(charArrayB);

		// Compare sorted char arrays
		for (int i = 0; i < c; i++) {
		    if (charArrayA[i] != charArrayB[i]) {
		        System.out.println("Not an anagram");
		        return;
		    }
		}

		System.out.println("It is an anagram");
		
	}

}

/*
*/