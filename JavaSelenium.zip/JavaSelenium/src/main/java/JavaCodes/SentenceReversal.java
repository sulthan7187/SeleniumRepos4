package JavaCodes;

public class SentenceReversal {

	public static void main(String[] args) {
		String s = "Apple was good";
        String str ="";
        int a = s.length();
        String b[] = s.split(" ");
        for(String g : b) {
        	String rev = "";
        	int n = g.length();
        for(int i=n-1; i>=0;i--) {
        	rev= rev+g.charAt(i);
        }
        str = str+rev+" ";
        }
        System.out.println(str);
    }
}
