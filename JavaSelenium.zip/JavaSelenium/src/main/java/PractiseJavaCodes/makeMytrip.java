package PractiseJavaCodes;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class makeMytrip {

	public static void main(String[] args) throws InterruptedException, IOException {
		// TODO Auto-generated method stub
		EdgeDriver driver = new EdgeDriver();
		driver.get("https://www.makemytrip.com/");
		driver.manage().window().maximize();
		Thread.sleep(15000);
		try {
		WebDriverWait wt = new WebDriverWait(driver, Duration.ofSeconds(15));
		wt.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[contains(@id, 'fromCity')]"))).click();
		
		
		 driver.findElement(By.xpath("//input[contains(@placeholder, 'From')]")).sendKeys("Mum");
		
		  List<WebElement> list = driver.findElements(By.xpath("//li[contains(@role, 'option')]"));
		String a = "Mumbai";
		for(WebElement b : list) {
			String d = b.getText();
			if(d.contains(a)) {
				b.click();
			}
			
		}
		}
		catch(Exception e) {
			File f = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			//Files.(f, new File("C:\\TestLeaf\\SeleniumCucumber\\test-output\\Screenshots"));
			FileUtils.copyFile(f, new File(".//ScreenShotSul/Sucfai.png"));
			System.out.println("this " + e.getMessage());
		}

	}

}
