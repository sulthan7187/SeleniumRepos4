package PractiseJavaCodes;

import java.util.Arrays;

public class Compare {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] l1 = {"a", "b", "c"};
        String[] l2 = {"b", "d", "a"};
        
        // Sort arrays
        Arrays.sort(l1);
        Arrays.sort(l2);
        
        String str = l1.toString();
        String com = l2.toString();
        
        
        int len = str.length();
        int leng = com.length();
        
        for(int i = 0; i<len; i++) {
        	if(str.equals(com)) {
        		System.out.println("l1 and l2 are equal");
        	    return;
        	}
        	
        }

	}

}
