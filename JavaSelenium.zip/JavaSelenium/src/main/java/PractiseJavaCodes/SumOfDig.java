package PractiseJavaCodes;

public class SumOfDig {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 22622;
		int rem=0;
		
		while(a>0) {
			rem += a%10;
			a=a/10;
			
		}
		
		System.out.println(rem);
	}

}
