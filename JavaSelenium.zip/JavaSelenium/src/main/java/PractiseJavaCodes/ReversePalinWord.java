package PractiseJavaCodes;

public class ReversePalinWord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "TomoTe";
		String rev = "";
		int b = a.length();
		for(int i = b-1; i>=0;i--) {
			rev = rev + a.charAt(i);
		}
		System.out.println(rev);
		if(rev.toLowerCase().equals(a.toLowerCase())) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}

	}

}
