package PractiseJavaCodes;

import java.util.HashMap;
import java.util.Map;

public class BNYMNEW {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "aaabbccd";
        StringBuilder output = new StringBuilder();
        int count = 1; // Initialize count of consecutive characters
        for (int i = 1; i <= input.length(); i++) {
            if (i == input.length() || input.charAt(i) != input.charAt(i - 1)) {
                StringBuilder append = output.append(input.charAt(i - 1));
                StringBuilder append2 = output.append(count);
                count = 1; // Reset count for next character
            } else {
                count++;
            }
        }
        System.out.println("Input String : \"" + input + "\"");
        System.out.println("Output : " + output.toString());

	}

}
