package PractiseJavaCodes;

public class ReverseSent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Java is Good";
		String rev = "";
		int b = a.length();
		String[] c = a.split(" ");
		for(String v : c) {
			String sent ="";
			int j = v.length();
			for(int i=j-1;i>=0;i--) {
				sent = sent+v.charAt(i);	
			}
			rev = rev+sent+" ";
		}
		System.out.println(" "+ rev);

	}

}
