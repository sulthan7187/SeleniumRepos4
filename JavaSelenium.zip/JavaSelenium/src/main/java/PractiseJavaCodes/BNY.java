package PractiseJavaCodes;

public class BNY {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[] = {1,2,3,4,5};
		int b = a.length;
		for(int i = 0; i<b;i++) {
			String d = "A"+ a[i];
			if(i>=1) {
			d = "_"+d;
			}
			System.out.print(d);
		}
		

	}

}
