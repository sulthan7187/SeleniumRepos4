package PractiseJavaCodes;

public class ReverseNumPalin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = 22622;
		int sum =0 , temp, rem;
		temp = a;
		while(a>0) {
			rem = a%10;
			a=a/10;
			sum = sum * 10 + rem;
				
		}
		System.out.println(sum);
		if(temp==sum) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palin");
		}
		
		

	}

}
