package PractiseJavaCodes;

public class PrintingafterDups {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a = "Autoomation was was good";
		String s2[] = a.split(" ");
		String emp = "";
		int b = a.length();
		for(int i =5; i<b; i++) {
			emp += a.charAt(i);
		}
		System.out.println(emp);

	}

}
