package PractiseJavaCodes;

public class ReversingSentence {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "elppA saw doog";
		String s2[] = s1.split(" ");
		int a = s2.length;
		String emp = "";
		for(String b:s2) {
			String rev = "";
			for(int i = b.length()-1;i>=0;i--) {
				rev = rev+b.charAt(i);
			}
			emp = emp + rev + " ";
		}
		System.out.println(emp);
		String s3 = emp.split(" ").toString();
		String s4 = s2.toString();
		if(s3.toLowerCase().equals(s4.toLowerCase())) {
			System.out.println("Palindrome");
		}
		else {
			System.out.println("Not a Palindrome");
		}

	}

}
