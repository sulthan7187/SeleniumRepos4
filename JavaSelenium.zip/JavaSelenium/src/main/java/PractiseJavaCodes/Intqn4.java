package PractiseJavaCodes;

public class Intqn4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s = "Autoomation";
		int a = 5;
		String out = "";
		int b = s.length();
		for(int i = a; i<b;i++) {
			out += s.charAt(i);
		}
		System.out.println(out);
		
		/*String s2 = s.substring(5);
		System.out.println(s2);*/

	}

}
