package PractiseJavaCodes;

import java.util.Arrays;

public class Intqn3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] l1 = {"a", "b", "c"};
        String[] l2 = {"b", "d", "a"};
        
        
        
        // Sort arrays
        Arrays.sort(l1);
        Arrays.sort(l2);
        
        // Print sorted arrays (optional)
        System.out.println("Sorted l1: " + Arrays.toString(l1));
        System.out.println("Sorted l2: " + Arrays.toString(l2));
        
        // Compare arrays
        if (Arrays.equals(l1, l2)) {
            System.out.println("Arrays have the same elements.");
        } else {
            System.out.println("Arrays do not have the same elements.");
        }
	
		

	}

}
