package StepDef;

import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BaseClass {
	
	static WebDriver driver = null;
	
	public static void init() {
		if(driver == null) { 
		driver = new ChromeDriver();
		driver.get("https://www.linkedin.com/checkpoint/lg/sign-in-another-account?trk=guest_homepage-basic_nav-header-signin");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		}
	}
	/*public static void winswi() {
		String winHandle = driver.getWindowHandle();
		Set<String> wHles = driver.getWindowHandles();
		for (String handle: wHles) {
		    if (!handle.equals(winHandle)) {
		        driver.switchTo().window(handle);
		        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(15));
		        break;
		    }
		}
	}*/
	public static void shadow() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		//String str = "return document.querySelector('#open-shadow').shadowRoot.querySelector('#fname')";
		String str = "return document.querySelector('#__image_picker_web-file-input').shadowRoot.querySelector('#flt-text-editing transparentTextEditing')";
		WebElement fname = (WebElement)js.executeScript(str);
		fname.sendKeys("sulthanallaudeen.sk@gmail.com");
	}

}
