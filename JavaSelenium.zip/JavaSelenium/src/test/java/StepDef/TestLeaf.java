package StepDef;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class TestLeaf extends BaseClass {

	static PageObject po = new PageObject();

@Given("I enter Username as {string}")
public static void lUrl(String uname) {
	BaseClass.init();
	po.usename().sendKeys(uname);
}

/*@Given("Switch to another window and click on Login")
public static void winswitch() {
	BaseClass.winswi();
}*/
 
@Given("I enter password as {string}")
public static void shad(String pwd) {
    po.pwdname().sendKeys(pwd);
}

@When("I click on Signin")
public static void sigin() {
	po.signin().click();
}

}
