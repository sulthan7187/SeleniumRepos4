package StepDef;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PageObject extends BaseClass{
	
public WebElement usename() {
return driver.findElement(By.xpath("//input[contains(@id, 'username')]"));
}
    
public WebElement pwdname() {
	return driver.findElement(By.xpath("//input[contains(@id, 'password')]")); 
        }

public WebElement signin() {
	return driver.findElement(By.xpath("//button[contains(text(), 'Sign in')]")); 
        }

}
