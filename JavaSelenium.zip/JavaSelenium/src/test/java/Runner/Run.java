package Runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/Feature", glue = "StepDef", 
monochrome = true, plugin = "pretty", publish = true)

public class Run extends AbstractTestNGCucumberTests {
	
}
